<!DOCTYPE html>
<?php
include 'nav.php';
include 'connection.php';

if (isset($_GET['serial_no'])){
  $id = $_GET['serial_no'];
  $delete = "DELETE FROM expenses_table WHERE serial_no='$id'";
if ($conn->query($delete) === TRUE) {
  echo "
  <div class='alert alert-danger alert-dismissible fade show' role='alert'>
  <h4>Record deleted successfully</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
} else {
echo "
<div class='alert alert-warning alert-dismissible fade show' role='alert'>
<h4>Error deleting record:.$conn->error</h4>
<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}

}
  $select = "SELECT * FROM expenses_table";
  $result = $conn->query($select);

  $conn->close();

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employee</title>
</head>
<body>
<br /><br /><br /><br />

    <div class="container" style="">
    <h2>VIEW EXPENSES RECORDS</h2>

    <div class="table-responsive">
    <table class="table caption-top table-striped table-hover">
    <caption>List of Employee
    <a href='RegisterEmployee.php' class='btn btn-primary'>Add New</a>
    </caption>
  <thead>
    <tr>
      <th scope="col">S/N</th>
      <th scope="col">Expenses Type</th>
      <th scope="col">Amount</th>
      <th scope="col">Date</th>
      <th scope="col">Remark</th>
      <th scope="col">ACTION</th>
      
    </tr>
  </thead>
  <tbody>
  <?php 
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
    <tr>
      <th scope="row"><?php echo $row['serial_no']; ?></th>
      <td><?php echo $row['expenses_type']; ?></td>
      <td><?php echo $row['amount']; ?></td>
      <td><?php echo $row['date']; ?></td>
      <td><?php echo $row['remark']; ?></td>
      <td>
      <?php echo "<a href='ViewExpenses.php?serial_no=".$row['serial_no']."' class='btn btn-danger' >DELETE</a>" ?> 
      <?php echo "<a href='UpdateExpenses.php?serial_no=".$row['serial_no']."' class='btn btn-warning'>UPDATE</a>" ?>
    </td>
    </tr>
    <?php
    }
  } 

?>

  </tbody>
</table>
</div>
</div>
</body>
</html>
