<!DOCTYPE html>
<?php
// Database connection
include('connection.php');

// Function to generate OTP
function generateOTP() {
    $otp = rand(100000, 999999); // Generate a random 6-digit OTP
    return $otp;
}

// Function to send OTP (you can implement email or SMS sending logic here)
function sendOTP($email, $otp) {
    // Implement your code to send OTP via email or SMS
    // For example:
    return mail($email, "Your OTP for password reset", "Your OTP is: $otp");
}

// Function to save OTP to database
function saveOTP($email, $otp) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO forget_password (email, otp) VALUES (?, ?)");
    $stmt->bind_param("si", $email, $otp);
    $stmt->execute();
    $stmt->close();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Generate OTP
    $otp = generateOTP();

    // Save OTP to database
    saveOTP($email, $otp);

    // Send OTP to user
    $result = sendOTP($email, $otp);
    if($result){
    echo "
    <br/ ><br/ ><br/ ><br/ ><br/ >
    <center>
    <div class='card w-75 mb-3'>
    <div class='card-body'>
      <h5 class='card-title' style='color: green;'><strong>SENT!</strong></h5>
      <p class='card-text' style='color: orange';>OTP has been sent to your email. Please check your email..</p>
      <a href='verify_otp.php?email=$email' class='btn btn-primary'>OK</a>
    </div>
  </div>
  </center>
    ";
    exit();
}
else{
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
    <h4>Error.$conn->error</h4>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>
  ";
}
}

// HTML form to take user input (email)
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Forgot Password</title>
</head>
<body>
    <center>
<br /><br /><br /><br />

    <div class="container" style="">
    <h2>ENTER TYOUR EMAIL BELOW</h2>
    <br />
<div class="conatiner" style="width: 40%">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
<div class="mb-3">
  <label for="Email" class="form-label">Email address *</label>
  <input type="email" class="form-control" name="email" placeholder="name@example.com" required>
</div>

<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="login" value="SEND OTP" required>
</div>
</form>
</div>
</div>
</center>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>