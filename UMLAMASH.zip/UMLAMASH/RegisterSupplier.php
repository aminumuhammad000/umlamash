<!DOCTYPE html>
<html lang="en">
<?php
include 'nav.php';
include 'connection.php';
$serial_no = $supplier_name = $supplier_id = $phone = '';

if(isset($_POST['submit'])){
  $supplier_name = htmlspecialchars($_POST['sname']);
  $supplier_id = htmlspecialchars($_POST['sid']);
  $phone = htmlspecialchars($_POST['snumber']);


  $select = "SELECT serial_no FROM supplier_table ORDER BY serial_no DESC LIMIT 1";
  $result = $conn->query($select);

if($result->num_rows > 0){
  $row = $result->fetch_assoc();
  $last_id = $row['serial_no'];
  //incerment by one
  $new_id = $last_id + 1;
  }
  else{
     $new_id = 1;
  }

  $sql = "INSERT INTO supplier_table() VALUES('$new_id', '$supplier_name', '$supplier_id', '$phone')";
  
  if ($conn->query($sql) === TRUE) {
    echo "
    <br/ ><br/ ><br/ ><br/ ><br/ >
    <center>
    <div class='card w-75 mb-3'>
    <div class='card-body'>
      <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
      <p class='card-text' style='color: orange';>Record has been successfully sent.</p>
      <a href='RegisterSupplier.php' class='btn btn-primary'>OK</a>
    </div>
  </div>
  </center>
    ";
      exit();
  } 
  else {
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
    <h4>Record Not Sent.$conn->error</h4>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>
  ";
  }
  $conn->close();
}

?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Register</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h1>SUPPLIER REGISTRATION FORM</h1>
        <br />
<div class="conatiner" style="width: 40%">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">

<div class="mb-3">
<label for="supplier name" class="form-label">supplier name *</label>
  <input type="text" class="form-control" name="sname" placeholder="supplier name">
  </div>

<div class="mb-3">
<label for="supplier id" class="form-label">supplier id *</label>
  <input type="text" class="form-control" name="sid" placeholder="supplier id">
  </div>

  <div class="mb-3">
<label for="contact number" class="form-label">contact number *</label>
  <input type="text" class="form-control" name="snumber" placeholder="eg 8100015498">
  </div>

<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="submit" value="REGISTER">
</div>
</form>
</div>
</div>

</body>
</html>