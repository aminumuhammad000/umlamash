<!DOCTYPE html>
<?php
session_start();
ob_start();
include 'connection.php';
$email = $password = '';
if(isset($_POST['login'])){
$email = htmlspecialchars($_POST['email']);
$password = $_POST['password'];
$password = md5($password);

$select = "SELECT email, password FROM admin_table WHERE email = '$email' and password = '$password'";
$result = $conn->query($select);
if ($result->num_rows > 0){
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>login successfull.</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
   header('location: index.php');
   $_SESSION['email'] = $email;
   exit();
  }
  else{
    echo "
    <div class='alert alert-warning alert-dismissible fade show' role='alert'>
    <h4>email or password is incorrect!.$conn->error</h4>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>
  ";
  }

  $conn->close();
  ob_end_flush();
}


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <title>ADMIN LOGIN</title>
</head>
<body>
<!-- <div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong><h2></strong>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div> -->

<br /><br /><br /><br />

    <div class="container" style="">
    <h2>LOGIN FORM</h2>
    <br />
<div class="conatiner" style="width: 40%">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
<div class="mb-3">
  <label for="Email" class="form-label">Email address *</label>
  <input type="email" class="form-control" name="email" placeholder="name@example.com" required>
</div>


<div class="mb-3">
<label for="Password" class="form-label">Password *</label>
  <input type="password" class="form-control" name="password" placeholder="password">
</div>
<a href="RegisterAdmin.php" style="text-decoration: none;">Dont Have an Account Register</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="ForgotPassword.php" style="text-decoration: none; color: red;">Forget Password</a>

<p></p>
<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="login" value="LOGIN" required>
</div>
</form>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>