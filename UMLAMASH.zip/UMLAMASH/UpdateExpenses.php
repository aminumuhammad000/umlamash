<!DOCTYPE html>
<html lang="en">
    <?php
include 'nav.php';
include('connection.php');
if(isset($_GET['serial_no'])){
  $id = $_GET['serial_no'];
}
if(isset($_POST['update'])){
$expenses_type= htmlspecialchars($_POST['expenses_type']);
$amount = htmlspecialchars($_POST['amount']);
$date = htmlspecialchars($_POST['date']);
$remark = htmlspecialchars($_POST['remark']);
    
$update = "UPDATE expenses_table SET expenses_type='$expenses_type', amount='$amount', date='$date', remark='$remark' WHERE serial_no='$id'";
  if ($conn->query($update) === TRUE) {
    echo "
    <br/ ><br/ ><br/ ><br/ ><br/ >
    <center>
    <div class='card w-75 mb-3'>
    <div class='card-body'>
      <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
      <p class='card-text' style='color: orange';>Record has been successfully updated!.</p>
      <a href='ViewExpenses.php' class='btn btn-primary'>Back To View</a>
    </div>
  </div>
  </center>
    ";
      exit(); 
} else {
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error updating record:. $conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}
}
$conn->close();
    ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Employee</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h1>UPDATE EMPLOYEE RECORD</h1>
        <br />
<div class="conatiner" style="width: 40%">
<form action="" method="POST">
<?php
include('connection.php');
if(isset($_GET['serial_no'])){
$id = $_GET['serial_no'];
}
$select = "SELECT * FROM expenses_table WHERE serial_no='$id'";
$result =$conn->query($select);
while($row = $result->fetch_assoc()){
  ?>
<div class="mb-3">
<label for="customer name" class="form-label">Expenses Type *</label>
  <input type="text" class="form-control" name="expenses_type" value="<?php echo $row['expenses_type']; ?>" required>
  </div>
<div class="mb-3">
  <label for="vehicle number" class="form-label">Amount *</label>
  <input type="text" class="form-control" name="amount" value="<?php echo $row['amount']; ?>" required>
</div>


<div class="mb-3">
<label for="date" class="form-label">Date *</label>
  <input type="date" class="form-control" name="date" required>
</div>


<div class="mb-3">
<label for="fuel_type" class="form-label">Remark *</label>
<select class="form-select" aria-label="Default select example" name="remark" required>
  <option selected value="Good">Good</option>
  <option value="Very Good">Very Good</option>
  <option value="Not Good">Not Good</option>
</select>
</div>
<?php
}
?>

  <div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="update" value="REGISTER">
</div>
</form>
</div>
</body>
</html>