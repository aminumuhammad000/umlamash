<!DOCTYPE html>
<?php
include 'nav.php';
include 'connection.php';

if (isset($_GET['id'])){
  $id = $_GET['id'];
  $delete = "DELETE FROM tax_table WHERE id='$id'";
if ($conn->query($delete) === TRUE) {
  echo "
  <div class='alert alert-danger alert-dismissible fade show' role='alert'>
  <h4>Record deleted successfully</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
} else {
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error deleting record:.$conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}

}
  $select = "SELECT * FROM tax_table";
  $result = $conn->query($select);

  $conn->close();

?>
<script>

  </script>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Tax Record
    </title>
</head>
<body>
<br /><br /><br /><br />

	
    <div class="container" style="">
    <h2>VIEW TAX RECORDS</h2>
    <div class="table-responsive">
    <table class="table caption-top table-striped table-hover">
    <caption>List of Tax    
    <a href='RegisterTax.php' class='btn btn-primary'>Add New</a>
    </caption>
  <thead style="background-color: orange;">
    <tr>
    
      <th scope="col">S/N</th>
      <th scope="col">GST</th>
      <th scope="col">VAT</th>
      <th scope="col">IGST</th>
      <th scope="col">ACTION</th>
      
    </tr>
  </thead>
  <tbody>
    
  <?php 
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
  

    <tr>
      <th scope="row"><?php echo $row['Id']; ?></th>
      <td><?php echo $row['GST']; ?></td>
      <td><?php echo $row['VAT']; ?></td>
      <td><?php echo $row['IGST']; ?></td>
      
      <td>
      <?php echo "<a href='ViewTax.php?id=".$row['Id']."' class='btn btn-danger' >DELETE</a> " ?> 
      <?php echo "<a href='UpdateTax.php?serial_no=".$row['Id']."' class='btn btn-warning'>UPDATE</a>" ?>
    </td>
    </tr>
    <?php
    }
  } 

?>

  </tbody>
</table>
</div>
</div>
</body>
</html>
