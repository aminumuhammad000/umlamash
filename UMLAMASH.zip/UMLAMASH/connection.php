<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petroldb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    $err = die("Connection failed: " . $conn->connect_error);
}
$msg =  "Connected successfully";
?>
