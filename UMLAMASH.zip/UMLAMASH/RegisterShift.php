<!DOCTYPE html>
<html lang="en">
<?php
include 'nav.php';
include 'connection.php';
$serial_no = $shift_name = $start_tiame = $end_tiame = $cname = '';

if(isset($_POST['submit'])){
  $shift_name = htmlspecialchars($_POST['shiftname']);
  $start_tiame = htmlspecialchars($_POST['stime']);
  $end_tiame = htmlspecialchars($_POST['etime']);
  $cname = htmlspecialchars($_POST['cashiername']);

  $select = "SELECT serial_no FROM shift_table ORDER BY serial_no DESC LIMIT 1";
  $result = $conn->query($select);

if($result->num_rows > 0){
  $row = $result->fetch_assoc();
  $last_id = $row['serial_no'];
  //incerment by one
  $new_id = $last_id + 1;
  }
  else{
     $new_id = 1;
  }

  $sql = "INSERT INTO shift_table() VALUES('$new_id', '$shift_name', '$start_tiame', '$end_tiame', '$cname')";
  
  if ($conn->query($sql) === TRUE) {
    echo "
    <br/ ><br/ ><br/ ><br/ ><br/ >
    <center>
    <div class='card w-75 mb-3'>
    <div class='card-body'>
      <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
      <p class='card-text' style='color: orange';>Record has been successfully sent.</p>
      <a href='RegisterShift.php' class='btn btn-primary'>OK</a>
    </div>
  </div>
  </center>
    ";
      exit();
  } 
  else {
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
    <h4>Record Not Sent.$conn->error</h4>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>
  ";
  }
  $conn->close();
}

?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shift Register</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h1>SHIFT REGISTRATION FORM</h1>
        <br />

	
<div class="conatiner" style="width: 40%">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">

<div class="mb-3">
<label for="shift name" class="form-label">shift name *</label>
  <input type="text" class="form-control" name="shiftname" placeholder="shift name">
  </div>

  <div class="mb-3">
<label for="start time" class="form-label">start time *</label>
  <input type="time" class="form-control" name="stime">
  </div>

  <div class="mb-3">
<label for="end time" class="form-label">end time *</label>
  <input type="time" class="form-control" name="etime">
  </div>

  <div class="mb-3">
<label for="cashier name" class="form-label">cashier name *</label>
  <input type="text" class="form-control" name="cashiername" placeholder="cashier name">
  </div>
  
<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="submit" value="REGISTER">
</div>
</form>
</div>
</div>

</body>
</html>