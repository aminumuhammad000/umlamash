<?php
require 'nav.php';
include('connection.php');

$customer = "SELECT COUNT(*) As id FROM customer_table";
$result = $conn->query($customer);
$totalRows = $result->fetch_assoc();

$employee = "SELECT COUNT(*) As id FROM employee_table";
$result = $conn->query($employee);
$Employee_Rows = $result->fetch_assoc();


$shift = "SELECT COUNT(*) As id FROM shift_table";
$result = $conn->query($employee);
$Shift_Rows = $result->fetch_assoc();

$shift = "SELECT COUNT(*) As id FROM expenses_table";
$result = $conn->query($employee);
$Expenses_Rows = $result->fetch_assoc();

$shift = "SELECT COUNT(*) As id FROM supplier_table";
$result = $conn->query($employee);
$Supplier_Rows = $result->fetch_assoc();
?>
<!doctype html>
<html lang="en">

   <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>UMLAMASH PETROL STATION</title>

</head>
  <body>
    <br /><br /><br /><br />
    <center>
    <span class="d-block p-4 my-2 text-bg-primary" style="width: 90%;">
    <?php echo 'TOTAL NUMBER OF CUSTOMER '.$totalRows['id']; ?></span>

    <span class="d-block p-4 my-2 text-bg-warning" style="width: 90%;">
  <?php echo 'TOTAL NUMBER OF EMPLOYEE '.$Employee_Rows['id']; ?></span>

    <span class="d-block p-4 my-2 text-bg-danger" style="width: 90%;">
     <?php echo 'TOTAL NUMBER OF SHIFT '.$Shift_Rows['id']; ?></span>

    <span class="d-block p-4 my-2 text-bg-secondary" style="width: 90%;">
     <?php echo 'TOTAL NUMBER OF EXPENSES '.$Expenses_Rows['id']; ?></span>

     <span class="d-block p-4 my-2 text-bg-primary" style="width: 90%;">
     <?php echo 'TOTAL NUMBER OF SUPPLIER '.$Supplier_Rows['id']; ?></span>
     
</center>
</body>
 


</html>