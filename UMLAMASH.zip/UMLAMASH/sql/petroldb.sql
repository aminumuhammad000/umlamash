-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2024 at 12:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petroldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`fname`, `lname`, `email`, `password`) VALUES
('Aminu', 'Muhammad', 'aminu@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
('umar', 'lawan mashi', 'umar@gmailcom', '827ccb0eea8a706c4c34a16891f84e7b'),
('umar', 'lawan mashi', 'umar@gmailcom', '827ccb0eea8a706c4c34a16891f84e7b'),
('umar', 'lawan mashi', 'umar@gmailcom', '827ccb0eea8a706c4c34a16891f84e7b'),
('umar', 'lawan mashi', 'umar@gmailcom', '827ccb0eea8a706c4c34a16891f84e7b'),
('umar', 'lawan mashi', 'umar@gmailcom', '827ccb0eea8a706c4c34a16891f84e7b'),
('umar', 'lawan mashi', 'umar@gmailcom', '827ccb0eea8a706c4c34a16891f84e7b'),
('isah', 'abba', 'isah@gmail.com', 'ab8b73d488e1c3ae5763f49a6776d238'),
('isah', 'abba', 'isah@gmail.com', 'ab8b73d488e1c3ae5763f49a6776d238'),
('aminu', 'muhammad', 'aminumuhammad@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
('Aminu', 'Muhammad', 'aminumuhd@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `customer_table`
--

CREATE TABLE `customer_table` (
  `id` int(255) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_table`
--

INSERT INTO `customer_table` (`id`, `customer_name`, `customer_id`, `phone`) VALUES
(2, 'Aminu Muhammad', '100', '08100015498'),
(3, 'Abba Muhammad', '200', '08024230597'),
(4, 'Umar Lawan Mashi', '22', '08100015498');

-- --------------------------------------------------------

--
-- Table structure for table `employee_table`
--

CREATE TABLE `employee_table` (
  `emp_id` int(50) NOT NULL,
  `emp_name` varchar(50) NOT NULL,
  `emp_role` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee_table`
--

INSERT INTO `employee_table` (`emp_id`, `emp_name`, `emp_role`, `phone`) VALUES
(3, 'Aminu Muhammad', 'Manager', '08100015498'),
(4, 'Umar Lawan Mashi', 'Sacretary', '08024230598'),
(5, 'Musa Hassan', 'Sacretary', '08100015498');

-- --------------------------------------------------------

--
-- Table structure for table `expenses_table`
--

CREATE TABLE `expenses_table` (
  `serial_no` int(11) NOT NULL,
  `expenses_type` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `remark` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses_table`
--

INSERT INTO `expenses_table` (`serial_no`, `expenses_type`, `amount`, `date`, `remark`) VALUES
(1, 'Kudin man Engi', '20000', '2024-04-18', 0),
(2, 'Customer Allowance', '12000', '2024-04-17', 0);

-- --------------------------------------------------------

--
-- Table structure for table `forget_password`
--

CREATE TABLE `forget_password` (
  `email` varchar(255) NOT NULL,
  `otp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forget_password`
--

INSERT INTO `forget_password` (`email`, `otp`) VALUES
('aminumuhammad00015@gmail.com', 836402),
('aminumuhammad00015@gmail.com', 160207),
('aminumuhammad00015@gmail.com', 922188),
('aminumuhammad00015@gmail.com', 438480),
('aminumuhammad00015@gmail.com', 437338),
('aminumuhammad00015@gmail.com', 828464),
('aminumuhammad00015@gmail.com', 265969),
('aminumuhammad00015@gmail.com', 550575),
('aminumuhammad00015@gmail.com', 936038),
('aminumuhammad00015@gmail.com', 507240),
('aminumuhammad00015@gmail.com', 934604),
('aminumuhammad00015@gmail.com', 331886);

-- --------------------------------------------------------

--
-- Table structure for table `fuel_inventory_table`
--

CREATE TABLE `fuel_inventory_table` (
  `serial_no` int(20) NOT NULL,
  `fuel_type` varchar(50) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `puchace_price` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuel_inventory_table`
--

INSERT INTO `fuel_inventory_table` (`serial_no`, `fuel_type`, `quantity`, `puchace_price`, `date`) VALUES
(21, 'Diesel', '2', '1500', '2024-04-18'),
(22, 'Diesel', '2', '2000', '2024-04-19'),
(23, 'Gas', '2', '2000', '2024-04-20');

-- --------------------------------------------------------

--
-- Table structure for table `pump_table`
--

CREATE TABLE `pump_table` (
  `serial_no` varchar(50) NOT NULL,
  `pump_number` varchar(255) NOT NULL,
  `fuel_type` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pump_table`
--

INSERT INTO `pump_table` (`serial_no`, `pump_number`, `fuel_type`, `status`) VALUES
('1', '01', 'Petrol', 'active'),
('2', '03', '2', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sale_table`
--

CREATE TABLE `sale_table` (
  `serial_no` int(11) NOT NULL,
  `costomer_name` varchar(50) NOT NULL,
  `vehicle_number` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `fuel_type` varchar(50) NOT NULL,
  `quantity` int(20) NOT NULL,
  `price` varchar(50) NOT NULL,
  `total` varchar(255) NOT NULL,
  `final_total` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale_table`
--

INSERT INTO `sale_table` (`serial_no`, `costomer_name`, `vehicle_number`, `date`, `fuel_type`, `quantity`, `price`, `total`, `final_total`) VALUES
(2, 'Aminu Muhammad', '23hdj', '2024-04-15', 'Gas', 2, '2000', '2000', '2000'),
(3, 'Umar Lawan Mashi', '22jsh', '2024-04-18', '2', 2, '1500', '1500', '1500');

-- --------------------------------------------------------

--
-- Table structure for table `shift_table`
--

CREATE TABLE `shift_table` (
  `serial_no` int(255) NOT NULL,
  `shift_name` varchar(50) NOT NULL,
  `start_time` varchar(50) NOT NULL,
  `end_time` varchar(50) NOT NULL,
  `cashier_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shift_table`
--

INSERT INTO `shift_table` (`serial_no`, `shift_name`, `start_time`, `end_time`, `cashier_name`) VALUES
(2, 'evening', '12:00', '01:00', 'Aminu Muhammad'),
(3, 'Morning', '10:00', '12:00', 'Umar Lawan Mashi');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_table`
--

CREATE TABLE `supplier_table` (
  `serial_no` int(50) NOT NULL,
  `supplier_name` varchar(50) NOT NULL,
  `supplier_id` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_table`
--

INSERT INTO `supplier_table` (`serial_no`, `supplier_name`, `supplier_id`, `phone`) VALUES
(0, 'MUSA HAMZA', '2133 ', '98765432');

-- --------------------------------------------------------

--
-- Table structure for table `tax_table`
--

CREATE TABLE `tax_table` (
  `Id` int(50) NOT NULL,
  `GST` varchar(50) NOT NULL,
  `VAT` varchar(50) NOT NULL,
  `IGST` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tax_table`
--

INSERT INTO `tax_table` (`Id`, `GST`, `VAT`, `IGST`) VALUES
(2, '1.1%', '1.2%', '2.1%');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
