<!DOCTYPE html>
<?php
include 'nav.php';
include 'connection.php';

if (isset($_GET['emp_id'])){
  $id = $_GET['emp_id'];
  $delete = "DELETE FROM employee_table WHERE emp_id='$id'";
if ($conn->query($delete) === TRUE) {
  echo "
  <div class='alert alert-danger alert-dismissible fade show' role='alert'>
  <h4>Record deleted successfully</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
} else {
echo "
<div class='alert alert-warning alert-dismissible fade show' role='alert'>
<h4>Error deleting record:.$conn->error</h4>
<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}

}
  $select = "SELECT * FROM employee_table";
  $result = $conn->query($select);

  $conn->close();

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employee</title>
</head>
<body>
<br /><br /><br /><br />

    <div class="container" style="">
    <h2>VIEW EMPLOYEE RECORDS</h2>

    <div class="table-responsive">
    <table class="table caption-top table-striped table-hover">
    <caption>List of Employee
    <a href='RegisterEmployee.php' class='btn btn-primary'>Add New</a>
    </caption>
  <thead>
    <tr>
      <th scope="col">Employee Id</th>
      <th scope="col">Employee Name</th>
      <th scope="col">Employee Role</th>
      <th scope="col">Employee Contact</th>
      <th scope="col">ACTION</th>
      
    </tr>
  </thead>
  <tbody>
  <?php 
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
    <tr>
      <th scope="row"><?php echo $row['emp_id']; ?></th>
      <td><?php echo $row['emp_name']; ?></td>
      <td><?php echo $row['emp_role']; ?></td>
      <td><a href="tel:<?php echo $row['phone'];?>" style="text-decoration: none;"><?php echo $row['phone']; ?></a></td>
      <td>
      <?php echo "<a href='ViewEmployee.php?emp_id=".$row['emp_id']."' class='btn btn-danger' >DELETE</a>" ?> 
      <?php echo "<a href='UpdateEmployee.php?emp_id=".$row['emp_id']."' class='btn btn-warning'>UPDATE</a>" ?>
    </td>
    </tr>
    <?php
    }
  } 

?>

  </tbody>
</table>
</div>
</div>
</body>
</html>
