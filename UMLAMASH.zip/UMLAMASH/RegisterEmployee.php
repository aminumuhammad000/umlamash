<!DOCTYPE html>
<html lang="en">
<?php
include 'nav.php';
include 'connection.php';
$serial_no = $emp_name = $emp_role = $phone = '';

if(isset($_POST['submit'])){
  $emp_name = htmlspecialchars($_POST['empname']);
  $emp_role = htmlspecialchars($_POST['emp_role']);
  $phone = htmlspecialchars($_POST['econtact']);

  $select = "SELECT emp_id FROM employee_table ORDER BY emp_id DESC LIMIT 1";
  $result = $conn->query($select);

if($result->num_rows > 0){
  $row = $result->fetch_assoc();
  $last_id = $row['emp_id'];
  //incerment by one
  $new_id = $last_id + 1;
  }
  else{
     $new_id = 1;
  }

  $sql = "INSERT INTO employee_table() VALUES('$new_id', '$emp_name', '$emp_role', '$phone')";
  
  if ($conn->query($sql) === TRUE) {
    echo "
    <br/ ><br/ ><br/ ><br/ ><br/ >
    <center>
    <div class='card w-75 mb-3'>
    <div class='card-body'>
      <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
      <p class='card-text' style='color: orange';>Record has been successfully sent.</p>
      <a href='RegisterEmployee.php' class='btn btn-primary'>OK</a>
    </div>
  </div>
  </center>
    ";
      exit();
  } 
  else {
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
    <h4>Record Not Sent.$conn->error</h4>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>
  ";
  }
  $conn->close();
}

?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Employee</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h1>EMPLOYEE REGISTERATION FORM</h1>
        <br />
<div class="conatiner" style="width: 40%">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">

  <div class="mb-3">
<label for="emp name" class="form-label">employee name *</label>
  <input type="text" class="form-control" name="empname" placeholder="emp name">
  </div>

  <div class="mb-3">
<label for="emp role" class="form-label">employee role *</label>
<select name="emp_role" class="form-select" aria-label="Default select example" required>
  <option value="Manager">Manager</option>
  <option value="Cashier">Cashier</option>
  <option value="Sacretary">Sacretary</option>
  <option value="Accountant">Accountant</option>
</select>
</div>

<div class="mb-3">
<label for="emp contact" class="form-label">emp contact *</label>
  <input type="text" class="form-control" name="econtact" placeholder="eg 9876543">
  </div>

<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="submit" value="REGISTER">
</div>
</form>
</div>
</div>

</body>
</html>