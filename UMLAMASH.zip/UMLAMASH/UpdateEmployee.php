<!DOCTYPE html>
<html lang="en">
    <?php
include 'nav.php';
include('connection.php');
if(isset($_POST['update'])){
 $emp_id = $_GET['emp_id'];
 $emp_name = $_POST['emp_name'];
 $emp_role = $_POST['emp_role'];
 $phone = $_POST['phone'];
  $update = "UPDATE employee_table SET emp_id='$emp_id', emp_name='$emp_name', emp_role='$emp_role', phone='$phone' WHERE emp_id='$emp_id'";
  if ($conn->query($update) === TRUE) {
    echo "
    <br/ ><br/ ><br/ ><br/ ><br/ >
    <center>
    <div class='card w-75 mb-3'>
    <div class='card-body'>
      <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
      <p class='card-text' style='color: orange';>Record has been successfully updated!.</p>
      <a href='ViewEmployee.php' class='btn btn-primary'>Back To View</a>
    </div>
  </div>
  </center>
    ";
      exit(); 
} else {
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error updating record:. $conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}
}
$conn->close();
    ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Employee</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h1>UPDATE EMPLOYEE RECORD</h1>
        <br />
<div class="conatiner" style="width: 40%">
<form action="" method="POST">
<?php
include('connection.php');
if(isset($_GET['emp_id'])){
$id = $_GET['emp_id'];
}
$select = "SELECT * FROM employee_table WHERE emp_id='$id'";
$result =$conn->query($select);
while($row = $result->fetch_assoc()){
  ?>
<div class="mb-3">
<label for="emp id" class="form-label">emp id *</label>
  <input type="text" class="form-control" name="emp_id" value="<?php echo $row['emp_id']; ?>">
  </div>

  <div class="mb-3">
<label for="emp name" class="form-label">emp name *</label>
  <input type="text" class="form-control" name="emp_name" value="<?php echo $row['emp_name']; ?>">
  </div>

  <div class="mb-3">
<label for="Password" class="form-label">emp role *</label>
<select class="form-select" aria-label="Default select example" name="emp_role" value="<?php echo $row['emp_role']; ?>" required>
  <option value="Manager">Manager</option>
  <option value="Cashier">Cashier</option>
  <option value="Sacretary">Sacretary</option>
  <option value="Accountant">Accountant</option>
</select>
</div>

<div class="mb-3">
<label for="emp contact" class="form-label">emp contact *</label>
  <input type="text" class="form-control" name="phone" value="<?php echo $row['phone']; ?>">
  </div>
  <?php
}
?>
<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="update" value="UPDATE">
</div>
</form>
</div>
</div>

</body>
</html>