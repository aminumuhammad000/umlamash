<!DOCTYPE html>
<?php
$serial_no = ""; // Initialize the variable
include 'nav.php';
include('connection.php');

if(isset($_GET['serial_no'])){
   $serial_no = $_GET['serial_no']; // Assign the value to $serial_no
}
if(isset($_POST['update'])){
  $fueltype = htmlspecialchars($_POST['fueltype']);
  $quantity = htmlspecialchars($_POST['quantity']); // Typo here, should be 'quantity'
  $purchase = htmlspecialchars($_POST['purchase']); // Typo here, should be 'purchase'
  $date = htmlspecialchars($_POST['date']);
  $sql = "UPDATE fuel_inventory_table SET fuel_type='$fueltype', quantity='$quantity', puchace_price='$purchase', date='$date' WHERE serial_no ='$serial_no'"; // Use $serial_no here instead of $id
  if ($conn->query($sql) === TRUE) {
    echo "
      <br/ ><br/ ><br/ ><br/ ><br/ >
      <center>
      <div class='card w-75 mb-3'>
      <div class='card-body'>
        <h5 class='card-title' style='color: green;'><strong>SUCCESS!</strong></h5>
        <p class='card-text' style='color: orange;'>Record has been successfully updated!.</p>
        <a href='ViewFuelInventory.php' class='btn btn-primary'>Back To View</a>
      </div>
    </div>
    </center>
      ";
    exit();
  } else {
    echo "
    <div class='alert alert-warning alert-dismissible fade show' role='alert'>
    <h4>Error updating record:. $conn->error</h4>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>
  ";
  }
}
$conn->close();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FUEL INVENTORY</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h2>UPDATE FUEL INVENTORY</h2>
        <br />
<div class="conatiner" style="width: 40%">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
<?php
include('connection.php');
if(isset($_GET['serial_no'])){
$serial_no = $_GET['serial_no'];
}
$select = "SELECT * FROM fuel_inventory_table WHERE serial_no = '$serial_no'";
$result =$conn->query($select);
while($row = $result->fetch_assoc()){
  ?>
<div class="mb-3">
<label for="fuel type" class="form-label">select fuel type *</label>
  <input type="text" class="form-control" name="fueltype" value="<?php echo $row['fuel_type']; ?>" required>
</div>

  <div class="mb-3">
  <label for="Last Name" class="form-label">Quantity *</label>
  <input type="text" class="form-control" name="quantity" value="<?php echo $row['quantity']; ?>" required>
</div>

<div class="mb-3">
  <label for="puchase" class="form-label">purchase *</label>
  <input type="text" class="form-control" name="purchase" value="<?php echo $row['puchace_price']; ?>">
</div>


<div class="mb-3">
<label for="date" class="form-label">Date *</label>
  <input type="text" class="form-control" name="date" value="<?php echo $row['date']; ?>">
</div>
<?php
}
?>
<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="update" value="UPDATE">
</div>
</form>
</div>
</div>


</body>
</html>


