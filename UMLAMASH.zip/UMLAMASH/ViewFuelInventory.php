<!DOCTYPE html>
<?php
include 'nav.php';
include 'connection.php';

if (isset($_GET['serial_no'])){
  $serial_no = $_GET['serial_no'];
  $delete = "DELETE FROM fuel_inventory_table WHERE serial_no='$serial_no'";
if ($conn->query($delete) === TRUE) {
  echo "
  <div class='alert alert-danger alert-dismissible fade show' role='alert'>
  <h4>Record deleted successfully</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
} else {
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error deleting record:.$conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
 
}

}
$select = "SELECT * FROM fuel_inventory_table";
$result = $conn->query($select);

  $conn->close();

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employee</title>
</head>
<body>
<br /><br /><br /><br />

    <div class="container" style="">
    <h2>VIEW FUEL INVENTORY RECORDS</h2>

    <div class="table-responsive">
    <table class="table caption-top table-striped table-hover">
    <caption>List of Inventory Records
    <a href='RegisterFuelInventory.php' class='btn btn-primary'>Add New</a>
    </caption>
  <thead>
    <tr>
      <th scope="col">S/N</th>
      <th scope="col">Fuel Type</th>
      <th scope="col">Quantity</th>
      <th scope="col">Purchase</th>
      <th scope="col">Date</th>
      <th scope="col">ACTION</th>
      
    </tr>
  </thead>
        
  <tbody>
  <?php 
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
  

    <tr>
      <th scope="row"><?php echo $row['serial_no']; ?></th>
      <td><?php echo $row['fuel_type']; ?></td>
      <td><?php echo $row['quantity']; ?></td>
      <td><?php echo $row['puchace_price']; ?></td>
      <td><?php echo $row['date']; ?></td>
      <td>
      
        <?php echo "<a href='ViewFuelInventory.php?serial_no=".$row['serial_no']."' class='btn btn-danger'>DELETE</a>" ?>
        <?php echo "<a href='UpdateFuelInventory.php?serial_no=".$row['serial_no']."' class='btn btn-warning'>UPDATE</a>" ?>
    
      </td>
    </tr>
    <?php
    }
  } 

?>  
  </tbody>
</table>
</div>
</div>
</body>
</html>
