<!DOCTYPE html>
<?php
include 'nav.php';
include 'connection.php';

if (isset($_GET['serial_no'])){
  $id = $_GET['serial_no'];
  $delete = "DELETE FROM shift_table WHERE serial_no='$id'";
if ($conn->query($delete) === TRUE) {
  echo "
  <div class='alert alert-danger alert-dismissible fade show' role='alert'>
  <h4>Record deleted successfully</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
} else {
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error deleting record:.$conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}

}
  $select = "SELECT * FROM shift_table";
  $result = $conn->query($select);

  $conn->close();

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Shift Record</title>
</head>
<body>
<br /><br /><br /><br />

	
    <div class="container" style="">
    <h2>VIEW SHIFT RECORDS</h2>
    <div class="table-responsive">
    <table class="table caption-top table-striped table-hover">
    <caption>List of shift
    <a href='RegisterShift.php' class='btn btn-primary'>Add New</a>
    </caption>
  <thead style="background-color: orange;">
    <tr>
      <th scope="col">S/N</th>
      <th scope="col">SHIFT NAME</th>
      <th scope="col">START TIME</th>
      <th scope="col">END TIME</th>
      <th scope="col">CASHIER NAME</th>
      <th scope="col">ACTION</th>
      
    </tr>
  </thead>
  <tbody>
  <?php 
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
    <tr>
      <th scope="row"><?php echo $row['serial_no']; ?></th>
      <td><?php echo $row['shift_name']; ?></td>
      <td><?php echo $row['start_time']; ?></td>
      <td><?php echo $row['end_time']; ?></td>
      <td><?php echo $row['cashier_name']; ?></td>
      <td>
      <?php echo "<a href='ViewShift.php?serial_no=".$row['serial_no']."' class='btn btn-danger' >DELETE</a>" ?> 
      <?php echo "<a href='UpdateShift.php?serial_no=".$row['serial_no']."' class='btn btn-warning'>UPDATE</a>" ?>
    </td>
    </tr>
    <?php
    }
  } 

?>
</tbody>
</table>
</div>
</div>
</body>
</html>
