<!DOCTYPE html>
<?php
include 'nav.php';
include 'connection.php';
$serial_no = $customer_name = $vehicle_no = $date = $fueltype = $quantity = $price = $total = $finaltotal = '';

if(isset($_POST['submit'])){
  $customer_name = htmlspecialchars($_POST['customer_name']);
  $vehicle_no = htmlspecialchars($_POST['vehicle_number']);
  $date = htmlspecialchars($_POST['date']);
  $fueltype = htmlspecialchars($_POST['fuel_type']);
  $quantity = htmlspecialchars($_POST['quantity']);
  $price = htmlspecialchars($_POST['price']);
  $total = htmlspecialchars($_POST['total']);
  $finaltotal = htmlspecialchars($_POST['ftotal']);
  

  $select = "SELECT serial_no FROM sale_table ORDER BY serial_no DESC LIMIT 1";
  $result = $conn->query($select);

if($result->num_rows > 0){
  $row = $result->fetch_assoc();
  $last_id = $row['serial_no'];
  //incerment by one
  $new_id = $last_id + 1;
  }
  else{
     $new_id = 1;
  }

  $sql = "INSERT INTO sale_table() VALUES('$new_id', '$customer_name', '$vehicle_no', '$date', '$fueltype', '$quantity', '$price', '$total', '$finaltotal')";
  
  if ($conn->query($sql) === TRUE) {
    echo "
    <br/ ><br/ ><br/ ><br/ ><br/ >
    <center>
    <div class='card w-75 mb-3'>
    <div class='card-body'>
      <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
      <p class='card-text' style='color: orange';>Record has been successfully sent.</p>
      <a href='RegisterSale.php' class='btn btn-primary'>OK</a>
    </div>
  </div>
  </center>
    ";
      exit();
  } 
  else {
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
    <h4>Record Not Sent.$conn->error</h4>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>
  ";
  }
  $conn->close();
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SALES MANAGEMENT</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h2>SALES MANAGEMENT</h2>
        <br />
<div class="conatiner" style="width: 40%">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
<div class="mb-3">
<label for="customer name" class="form-label">costomer name *</label>
  <input type="text" class="form-control" name="customer_name" placeholder="john" required>
  </div>

<div class="mb-3">
  <label for="vehicle number" class="form-label">vehicle number*</label>
  <input type="text" class="form-control" name="vehicle_number" placeholder="vehicle number" required>
</div>


<div class="mb-3">
<label for="date" class="form-label">Date *</label>
  <input type="date" class="form-control" name="date" required>
</div>

<div class="mb-3">
<label for="fuel_type" class="form-label">select fuel type *</label>
<select class="form-select" aria-label="Default select example" name="fuel_type" required>
  <option selected>Petrol</option>
  <option value="1">Gas</option>
  <option value="2">Diesel</option>
  <option value="3">kerosane</option>
</select>
</div>

<div class="mb-3">
<label for="quantity" class="form-label">Quantity *</label>
  <input type="number" class="form-control" name="quantity" required min=0 placeholder="Quantity">
</div>

<div class="mb-3">
<label for="price" class="form-label">Price *</label>
  <input type="number" class="form-control" name="price" required min=0 placeholder="Price">
</div>

<div class="mb-3">
<label for="total" class="form-label">Total *</label>
  <input type="number" class="form-control" name="total" required min=0 placeholder="Total">
</div>

<div class="mb-3">
<label for="final total" class="form-label">Final Total *</label>
  <input type="number" class="form-control" name="ftotal" required min=0 placeholder="Final Total">
</div>

<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="submit" value="REGISTER">
</div>
</form>
</div>
</div>
</body>
</html>