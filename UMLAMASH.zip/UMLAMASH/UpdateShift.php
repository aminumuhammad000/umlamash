<!DOCTYPE html>
<html lang="en">
    <?php
include 'nav.php';
include('connection.php');
if(isset($_GET['serial_no'])){
$id = $_GET['serial_no'];
}
if(isset($_POST['update'])){
$shift_name = $_POST['shiftname'];
$stime = $_POST['stime'];
$etime = $_POST['etime'];
$cname = $_POST['cashiername'];

$update = "UPDATE shift_table SET shift_name='$shift_name', start_time='$stime', end_time='$etime', cashier_name='$cname' WHERE serial_no='$id'";
if($conn->query($update) === TRUE){
  echo "
  <br/ ><br/ ><br/ ><br/ ><br/ >
  <center>
  <div class='card w-75 mb-3'>
  <div class='card-body'>
    <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
    <p class='card-text' style='color: orange';>Record has been successfully updated!.</p>
    <a href='ViewShift.php' class='btn btn-primary'>Back To View</a>
  </div>
</div>
</center>
  ";
  exit();
}else{
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error updating record:. $conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}
}

$conn->close();
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Shift</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h1>UPDATE SHIFT RECORD</h1>
        <br />

	
<div class="conatiner" style="width: 40%">
<form action="" method="POST">
<?php
include('connection.php');
if(isset($_GET['serial_no'])){
$id = $_GET['serial_no'];
}
$select = "SELECT * FROM shift_table WHERE serial_no='$id'";
$result =$conn->query($select);
while($row = $result->fetch_assoc()){
  ?>
<div class="mb-3">
<label for="shift name" class="form-label">shift name *</label>
  <input type="text" class="form-control" name="shiftname" value="<?php echo $row['shift_name']; ?>" required>
  </div>

  <div class="mb-3">
<label for="start time" class="form-label">start time *</label>
  <input type="time" class="form-control" name="stime" value="12:00pm" required>
  </div>

  <div class="mb-3">
<label for="end time" class="form-label">end time *</label>
  <input type="time" class="form-control" name="etime" value="12:00pm" required>
  </div>

  <div class="mb-3">
<label for="cashier name" class="form-label">cashier name *</label>
  <input type="text" class="form-control" name="cashiername" value="<?php echo $row['cashier_name']; ?>" required>
  </div>
  <?php
}
?>
<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="update" value="UPDATE">
</div>
</form>
</div>
</div>

</body>
</html>