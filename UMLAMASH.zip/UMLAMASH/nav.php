<?php
  include('auth.php');
  ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<nav class="navbar navbar-expand-lg" style="background-color: orange">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Petrol Station</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           ADD RECORD MANAGEMENT
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="RegisterFuelInventory.php">Fuel Inventory</a></li>
            <li><a class="dropdown-item" href="RegisterSale.php">Sales Management</a></li>
            <li><a class="dropdown-item" href="RegisterPump.php">Pump Management</a></li>
            <li><a class="dropdown-item" href="RegisterEmployee.php">Employee Management</a></li>
            <li><a class="dropdown-item" href="RegisterCustomer.php">Customer Management</a></li>
            <li><a class="dropdown-item" href="RegisterShift.php">Shift Management</a></li>
            <li><a class="dropdown-item" href="RegisterExpenses.php">Expenses Management</a></li>
            <li><a class="dropdown-item" href="RegisterSupplier.php">Supply Management</a></li>
            <li><a class="dropdown-item" href="RegisterTax.php">Tax Management</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           VIEW RECOD MANAGEMENT
          </a>
          <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="ViewFuelInventory.php">Fuel Inventory</a></li>
            <li><a class="dropdown-item" href="ViewSale.php">Sales Management</a></li>
            <li><a class="dropdown-item" href="ViewPump.php">Pump Management</a></li>
            <li><a class="dropdown-item" href="ViewEmployee.php">Employee Management</a></li>
            <li><a class="dropdown-item" href="ViewCustomer.php">Customer Management</a></li>
            <li><a class="dropdown-item" href="ViewShift.php">Shift Management</a></li>
            <li><a class="dropdown-item" href="ViewExpenses.php">Expenses Management</a></li>
            <li><a class="dropdown-item" href="ViewSupplier.php">Supply Management</a></li>
            <li><a class="dropdown-item" href="ViewTax.php">Tax Management</a></li>
            <li><a class="dropdown-item" href="#">Todays Fuel Price</a></li>
            <li><a class="dropdown-item" href="#">Report And Analysis</a></li>
            <li><a class="dropdown-item" href="#">DataBase Backup</a></li>
          </ul>
        </li>

        </ul>
      <div class="nav-item dropdown">
          <a class="nav-link" href="#" data-bs-toggle="dropdown" aria-expanded="false">
          <img src="images/profile.png" class="nav-item dropdown" alt="Profile" style="width: 3vw;">
          </a>
               <ul class="dropdown-menu">
               <li><a class="dropdown-item" href="#">Login</a></li>
                <li><a class="dropdown-item" href="#">Regsiter</a></li>
                <li><a class="dropdown-item" href="#">Logout</a></li>
            </ul>
        </div>
    </div>
  </div>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
