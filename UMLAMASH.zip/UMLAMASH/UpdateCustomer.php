<!DOCTYPE html>
<?php
include 'nav.php';
include('connection.php');
if(isset($_GET['serial_no'])){
  $id = $_GET['serial_no'];
}
if(isset($_POST['update'])){
$cname = $_POST['cname'];
$cid = $_POST['cid'];
$phone = $_POST['phone'];
$update = "UPDATE customer_table SET customer_name='$cname',customer_id='$cid',phone='$phone' WHERE id ='$id'";

if($conn->query($update) === TRUE){
  echo "
  <br/ ><br/ ><br/ ><br/ ><br/ >
  <center>
  <div class='card w-75 mb-3'>
  <div class='card-body'>
    <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
    <p class='card-text' style='color: orange';>Record has been successfully updated!.</p>
    <a href='ViewCustomer.php' class='btn btn-primary'>Back To View</a>
  </div>
</div>
</center>
  ";
    exit();
}else{
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error updating record:. $conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}
}
$conn->close();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Customer</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h1>UPDATE CUSTOMER RECORD</h1>
        <br />
<div class="conatiner" style="width: 40%">
<?php
include('connection.php');
if(isset($_GET['serial_no'])){
$id = $_GET['serial_no'];
}
$select = "SELECT * FROM customer_table WHERE id='$id'";
$result =$conn->query($select);
while($row = $result->fetch_assoc()){
  ?>
<form action="" method="POST">
<div class="mb-3">
<label for="First Name" class="form-label">costomer name *</label>
  <input type="text" class="form-control" name="cname" value="<?php echo $row['customer_name'];?>" required>
  </div>

  <div class="mb-3">
  <label for="customer id" class="form-label">customer id *</label>
  <input type="text" class="form-control" name="cid" value="<?php echo $row['customer_id'];?>" required>
</div>

<div class="mb-3">
  <label for="phone number" class="form-label">phone number *</label>
  <input type="text" class="form-control" name="phone" value="<?php echo $row['phone'];?>" required>
</div>
<?php
}
?>
<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="update" value="UPDATE">
</div>
</form>
</div>
</div>
</body>
</html>