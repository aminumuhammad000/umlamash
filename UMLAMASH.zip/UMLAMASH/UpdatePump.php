<!DOCTYPE html>
<html lang="en">
    <?php
include 'nav.php';
include('connection.php');
if(isset($_GET['serial_no'])){
  $id = $_GET['serial_no'];
}
if(isset($_POST['update'])){
$pnumber = $_POST['pno'];
$ftype = $_POST['fuel_type'];
$status = $_POST['status'];
$update = "UPDATE pump_table SET pump_number='$pnumber', fuel_type='$ftype', status='$status' WHERE serial_no='$id'";

if($conn->query($update) === TRUE){
  echo "
  <br/ ><br/ ><br/ ><br/ ><br/ >
  <center>
  <div class='card w-75 mb-3'>
  <div class='card-body'>
    <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
    <p class='card-text' style='color: orange';>Record has been successfully updated!.</p>
    <a href='ViewPump.php' class='btn btn-primary'>Back To View</a>
  </div>
</div>
</center>
  ";
    exit();
}else{
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error updating record:. $conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}
}
$conn->close();
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Pump</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h1>UPDATE PUPM</h1>
        <br />
<div class="conatiner" style="width: 40%">
<form action="" method="POST">
<?php
include('connection.php');
if(isset($_GET['serial_no'])){
$id = $_GET['serial_no'];
}
$select = "SELECT * FROM pump_table WHERE serial_no='$id'";
$result =$conn->query($select);
while($row = $result->fetch_assoc()){
  ?>
<div class="mb-3">
<label for="Pump number" class="form-label">Pump number *</label>
  <input type="text" class="form-control" name="pno" value="<?php echo $row['pump_number'] ?>" />
  </div>

  <div class="mb-3">
<label for="Password" class="form-label">select fuel type *</label>
<select class="form-select" name="fuel_type" aria-label="Default select example" required>
  <option selected>Petrol</option>
  <option value="1">Gas</option>
  <option value="2">Diesel</option>
  <option value="3">kerosane</option>
</select>
</div>

<div class="mb-3">
<label for="Status" class="form-label">Status *</label>
<div class="form-check">
  <input class="form-check-input" type="radio" name="status" value="active"  >
  <label class="form-check-label" for="active">
    Active
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="status" value="not active" checked>
  <label class="form-check-label" for="not active">
    Not Active
  </label>
</div>
</div>
<?php
}
?>
<div class="mb-3">
  <input class="btn btn-primary" type="submit" class="form-control" name="update" value="UPDATE">
</div>
</form>
</div>
</div>

</body>
</html>