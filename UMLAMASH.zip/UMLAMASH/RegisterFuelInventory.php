<!DOCTYPE html>
<?php
include 'nav.php';
include 'connection.php';
$serial_no = $fueltype = $quantity = $puchase = $date = '';

if(isset($_POST['submit'])){
  $fueltype = htmlspecialchars($_POST['fueltype']);
  $quantity = htmlspecialchars($_POST['qauntity']);
  $puchase = htmlspecialchars($_POST['puchase']);
  $date = htmlspecialchars($_POST['date']);

  $select = "SELECT serial_no FROM fuel_inventory_table ORDER BY serial_no DESC LIMIT 1";
  $result = $conn->query($select);

if($result->num_rows > 0){
  $row = $result->fetch_assoc();
  $last_id = $row['serial_no'];
  //incerment by one
  $new_id = $last_id + 1;
  }
  else{
     $new_id = 1;
  }

  $sql = "INSERT INTO fuel_inventory_table () VALUES('$new_id', '$fueltype', '$quantity', '$puchase', '$date')";
  
  if ($conn->query($sql) === TRUE) {
    //echo "New record created successfully";
  echo "
  <br/ ><br/ ><br/ ><br/ ><br/ >
  <center>
  <div class='card w-75 mb-3'>
  <div class='card-body'>
    <h5 class='card-title' style='color: green;'><strong>SUCESS!</strong></h5>
    <p class='card-text' style='color: orange';>Record has been successfully sent.</p>
    <a href='RegisterFuelInventory.php' class='btn btn-primary'>OK</a>
  </div>
</div>
</center>
  ";
    exit();
  } 
  else {
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
    <h4>Record Not Sent.$conn->error</h4>
    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
  </div>
  ";
    $sql . '<br>' . $conn->error;
  }
  $conn->close();
}


 

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FUEL INVENTORY</title>
</head>
<body>
<br /><br /> <br /><br />
    <div class="container">
        <h2>FUEL INVENTORY</h2>
        <br />
<div class="conatiner" style="width: 40%">
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">

<div class="mb-3">
<label for="fuel type" class="form-label">select fuel type *</label>
<select class="form-select" name="fueltype" aria-label="Default select example" required>
  <option selected value="Petrol" >Petrol</option>
  <option value="Gas">Gas</option>
  <option value="Diesel">Diesel</option>
  <option value="kerosane">kerosane</option>
</select>

</div>
  <div class="mb-3">
  <label for="Last Name" class="form-label">Quantity *</label>
  <input type="number" class="form-control" name="qauntity"  min=0  placeholder="quantity">
</div>

<div class="mb-3">
  <label for="puchase" class="form-label">purchase *</label>
  <input type="text" class="form-control" name="puchase" placeholder="purchase">
</div>


<div class="mb-3">
<label for="date" class="form-label">Date *</label>
  <input type="date" class="form-control" name="date">
</div>
<div class="mb-3">

  <input class="btn btn-primary" type="submit" class="form-control" name="submit" value="REGISTER">
</div>
</form>
</div>
</div>
</body>
</html>