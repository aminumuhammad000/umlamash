<!DOCTYPE html>
<?php
include 'nav.php';
include 'connection.php';

if (isset($_GET['id'])){
  $id = $_GET['id'];
  $delete = "DELETE FROM customer_table WHERE id='$id'";
if ($conn->query($delete) === TRUE) {
  echo "
  <div class='alert alert-danger alert-dismissible fade show' role='alert'>
  <h4>Record deleted successfully</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>  
";
} else {
  echo "
  <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  <h4>Error deleting record:.$conn->error</h4>
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
";
}

}
  $select = "SELECT * FROM customer_table";
  $result = $conn->query($select);

  $conn->close();

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Customer Record</title>
</head>
<body>
<br /><br /><br /><br />

	
    <div class="container" style="">
    <h2>VIEW CUSTOMER RECORDS</h2>
    <div class="table-responsive">
    <table class="table caption-top table-striped table-hover">
    <caption>List of customers
    <a href='RegisterCustomer.php' class='btn btn-primary'>Add New</a>
    </caption>
  <thead style="background-color: orange;">
    <tr>
      <th scope="col">S/N</th>
      <th scope="col">CUSTOMER ID</th>
      <th scope="col">CUSTOMER NAME</th>
      <th scope="col">CONTACT NUMBER</th>
      <th scope="col">ACTION</th>
      
    </tr>
  </thead>
  <tbody>
  <?php 
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
    <tr>
      <th scope="row"><?php echo $row['id']; ?></th>
      <td><?php echo $row['customer_name']; ?></td>
      <td><?php echo $row['customer_id']; ?></td>
      <td><a href="tel:<?php echo $row['phone']; ?>" title="Click To Call"  style="text-decoration: none;"><?php echo $row['phone']; ?></a></td>
      <td>
      <?php echo "<a href='ViewCustomer.php?id=".$row['id']."' class='btn btn-danger' >DELETE</a>" ?> 
      <?php echo "<a href='UpdateCustomer.php?serial_no=".$row['id']."' class='btn btn-warning'>UPDATE</a>" ?>
    </td>
    </tr>
    <?php
    }
  } 
?> 
  </tbody>
</table>
</div>
</div>
</body>
</html>
